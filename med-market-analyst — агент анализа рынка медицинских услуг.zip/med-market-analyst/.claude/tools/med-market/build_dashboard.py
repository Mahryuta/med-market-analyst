#!/usr/bin/env python3
"""
Анализ рынка медицинских услуг -> интерактивный HTML-дашборд.

Вход: Excel-файл мониторинга цен (лист «Прайс» по умолчанию) с колонками
  Блок | Услуга | Цена | [Новая цена] | <Конкурент 1> | <Конкурент 2> | ...
Все колонки, кроме служебных, считаются ценами конкурентов (имя колонки = имя клиники).

Выход: один самодостаточный HTML-файл (без интернета, без внешних библиотек).

Запуск:
  python build_dashboard.py data/prices.xlsx -o output/dashboard.html --title "Рынок УЗИ, Челябинск"
"""
import argparse
import json
import math
import sys
from datetime import date
from pathlib import Path

import numpy as np
import pandas as pd

SERVICE_COLS = {"блок", "услуга", "цена", "новая цена", "код", "код услуги", "примечание"}
POSITIONS = ["ниже min", "нижний квартиль", "центр рынка", "верхний квартиль", "выше max", "н/д"]
OUTLIER_K = 3.0  # цена конкурента в 3+ раза выше/ниже медианы рынка -> аномалия


def to_price(v):
    """Число > 0 или None. Текст («по запросу»), нули и пустые значения исключаются."""
    if v is None:
        return None
    if isinstance(v, (int, float, np.integer, np.floating)):
        if isinstance(v, float) and math.isnan(v):
            return None
        return float(v) if v > 0 else None
    s = str(v).replace(" ", "").replace(" ", "").replace("₽", "").replace("руб.", "").replace(",", ".")
    try:
        x = float(s)
        return x if x > 0 else None
    except ValueError:
        return None


def position(p, prices):
    """Позиционирование цены относительно рынка (без жёсткого порога)."""
    if p is None or len(prices) < 2:
        return "н/д"
    lo, hi = min(prices), max(prices)
    if p < lo:
        return "ниже min"
    if p > hi:
        return "выше max"
    if len(prices) == 2:  # квартили по двум точкам не считаем
        return "центр рынка"
    q1, q3 = np.percentile(prices, [25, 75])
    if p < q1:
        return "нижний квартиль"
    if p <= q3:
        return "центр рынка"
    return "верхний квартиль"


def analyze(df):
    cols = {c.lower().strip(): c for c in df.columns}
    for need in ("блок", "услуга", "цена"):
        if need not in cols:
            sys.exit(f"Ошибка: в файле нет обязательной колонки «{need.capitalize()}». Есть: {list(df.columns)}")
    comp_cols = [c for c in df.columns if c.lower().strip() not in SERVICE_COLS and not str(c).startswith("Unnamed")]
    has_new = "новая цена" in cols

    records, issues = [], []
    for i, r in df.iterrows():
        service = str(r[cols["услуга"]]).strip()
        if not service or service == "nan":
            continue
        price = to_price(r[cols["цена"]])
        new_price = to_price(r[cols["новая цена"]]) if has_new else None
        comps = {}
        for c in comp_cols:
            raw = r[c]
            val = to_price(raw)
            if val is not None:
                comps[str(c)] = val
            elif raw is not None and not (isinstance(raw, float) and math.isnan(raw)):
                issues.append({"row": int(i) + 2, "service": service, "competitor": str(c),
                               "value": str(raw), "type": "исключено (текст/ноль)"})
        vals = list(comps.values())
        rec = {"block": str(r[cols["блок"]]).strip(), "service": service, "price": price,
               "new_price": new_price, "comps": comps, "n": len(vals)}
        if vals:
            med = float(np.median(vals))
            rec.update({"min": min(vals), "max": max(vals), "median": med})
            if len(vals) >= 3:
                for c, v in comps.items():
                    if v > med * OUTLIER_K or v < med / OUTLIER_K:
                        issues.append({"row": int(i) + 2, "service": service, "competitor": c,
                                       "value": f"{v:,.0f}".replace(",", " "), "type": "аномалия (в расчёте)"})
            elif len(vals) == 2 and max(vals) >= min(vals) * OUTLIER_K:
                issues.append({"row": int(i) + 2, "service": service, "competitor": " / ".join(comps),
                               "value": " / ".join(f"{v:,.0f}".replace(",", " ") for v in vals),
                               "type": "большой разброс (2 цены, проверить)"})
        for key, p in (("cur", price), ("new", new_price)):
            rec[f"pos_{key}"] = position(p, vals)
            rec[f"dev_{key}"] = (p / rec["median"] - 1) if (p and vals and len(vals) >= 2) else None
        records.append(rec)

    meta = {
        "competitors": [str(c) for c in comp_cols],
        "has_new": has_new and any(r["new_price"] for r in records),
        "issues": issues,
        "built": date.today().strftime("%d.%m.%Y"),
        "positions": POSITIONS,
    }
    return records, meta


def main():
    ap = argparse.ArgumentParser(description="Дашборд анализа рынка медицинских услуг")
    ap.add_argument("xlsx", help="Excel-файл мониторинга цен")
    ap.add_argument("-s", "--sheet", default="Прайс", help="Имя листа (по умолчанию «Прайс»)")
    ap.add_argument("-o", "--out", default="output/dashboard.html", help="Куда сохранить HTML")
    ap.add_argument("--title", default="Анализ рынка медицинских услуг", help="Заголовок дашборда")
    ap.add_argument("--subtitle", default="", help="Подзаголовок (город, период, источник)")
    a = ap.parse_args()

    try:
        df = pd.read_excel(a.xlsx, sheet_name=a.sheet)
    except ValueError:
        df = pd.read_excel(a.xlsx, sheet_name=0)
        print(f"Лист «{a.sheet}» не найден — взят первый лист.")
    df.columns = [str(c).strip() for c in df.columns]
    records, meta = analyze(df)
    meta.update({"title": a.title, "subtitle": a.subtitle, "source": Path(a.xlsx).name})

    tpl = (Path(__file__).parent / "dashboard_template.html").read_text(encoding="utf-8")
    html = (tpl.replace("__TITLE__", a.title)
               .replace("/*__DATA__*/null", json.dumps(records, ensure_ascii=False))
               .replace("/*__META__*/null", json.dumps(meta, ensure_ascii=False)))
    out = Path(a.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(html, encoding="utf-8")

    comparable = sum(1 for r in records if r["n"] >= 2)
    print(f"Готово: {out}")
    print(f"  услуг: {len(records)}, сопоставимых (≥2 цен конкурентов): {comparable}, "
          f"конкурентов: {len(meta['competitors'])}, замечаний к данным: {len(meta['issues'])}")


if __name__ == "__main__":
    main()
